# SQL Export

Generated on 2025-05-08 21:01:37.343467699 UTC by Fabricate v1.1.0

## Instructions

To load the data into your MySQL database, execute the following command replacing the values with your own:

```bash
export MYSQL_PWD=<password>
mysql -h hostname -u username -p database_name < load.sql
```

## Exported tables

This is the list of exported tables, with their corresponding row count:

    events_event: 100 rows
    users_booking: 100 rows
    users_customuser: 100 rows